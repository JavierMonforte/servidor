<?php
    define ('PATH', '/');
?>