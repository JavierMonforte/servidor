<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <title>Candi's</title>
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Last-Modified" content="0">
    <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <link rel="stylesheet" href="/app/css/portada.css?i=<?=rand(1,100)?>">
    <script></script>
</head>

<body>
<header>
    <div id="arribaIzquierda">
        <a href="/home/menu"><img src="/app/img/mas.png" alt=""></a>
        <a href="/home/menu" id="reservar" class="idioma">RESERVAR</a>
    </div>
    <div id="arribaDerecha">
        
        <a href="/home/menu"><img src="/app/img/menu.png" alt=""></a> 
        <a class="idioma" href="">ES</a>
        <a class="idioma"href="">EN</a>
    </div>
</header>
<div class="center">
</div>
    <footer>
        <div class="foot" id="abajoIdquierda">Avda Navarra</div>
        <div class="foot" id="abajoDerecha">669604539</div>
    </footer>
</body>

</HTML>