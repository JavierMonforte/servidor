<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Last-Modified" content="0">
    <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <link rel="stylesheet" href="./css/menu.css">

</head>

<body>
<header>
    <div id="arribaIzquierda">
        <a id="mas" class="idioma" href="?method=reservar">+</a>
        <a id="reservar" class="idioma" href="">RESERVAR</a>
    </div>
    <div id="arribaDerecha">
        
        <a class="idioma" href="?method=home">X</a> 
    </div>
</header>
<div id="center">
<ul>
    <li><a href="">TEAM</a></li>
    <li><a href="?method=reservar">RESERVAR</a></li>
    <li><a href="?method=servicios">SERVICIOS</a></li>
    <li><a href="">ABOUT</a></li>
    <li><a href="">TRABAJOS REALIZADOS</a></li>
    <li><a href="">NEWS</a></li>
    <li><a href="">SOMOS SOLIDARIOS</a></li>
</ul>
</div>
<footer>
    <div class="foot" id="abajoIdquierda">Avda Navarra</div>
    <div class="foot" id="abajoDerecha">669604539</div>
</footer>
   
</body>