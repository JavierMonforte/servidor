<header>
    <div id="arribaIzquierda">
        <a id="mas"  href="?method=reservar">+</a>
        <a id="reservar"  href="?method=reservar">RESERVAR</a>
    </div>
    <div id="arribaDerecha">
        
        <a class="idioma" href="?method=home">X</a> 
    </div>
</header>