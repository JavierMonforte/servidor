<!--13.- Realiza un script en el que un usuario introduzca un número, y vaya sumando cada una de sus cifras y devuelva el resultado.

-->
<!DOCTYPE html>
<HTML>

<head>
    <meta charset="UTF-8">
    <title>Ejercicio 13</title>
    <link rel="stylesheet" href="estilos.css">
    <script></script>
</head>

<body>
    <script></script>
</body>

</HTML>