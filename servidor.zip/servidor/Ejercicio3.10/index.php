<?php
require ('./App.php');
$app = new App();
$app->run();