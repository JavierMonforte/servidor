<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Colores coockies</title>
        <link rel="stylesheet" href="./css/estilos.css">

    </head>
    <body  style="background-color:<?=$color?>">
        <h1>BIENVENIDO</h1> 
        <ul>
            <li>
            <a href="?method=cambio&color=red">Rojo</a>
            </li>
            <li>
            <a href="?method=cambio&color=green">Verde</a>
            </li>
            <li>            
            <a href="?method=cambio&color=black">negro</a>
            </li>
        </ul>
    </body>
</html>