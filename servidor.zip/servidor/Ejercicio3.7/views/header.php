<header>
    <div id="nav">
    <h1>Series</h1>
    <a href="/servidor/Ejercicio3.7/index.php?method=0">Fibonachi</a>
    <a href="/servidor/Ejercicio3.7/index.php?method=1">Potencias</a>
    <a href="/servidor/Ejercicio3.7/index.php?method=2">Factorial</a>
    <a href="/servidor/Ejercicio3.7/index.php?method=3">Primos</a>
    </div>
</header>