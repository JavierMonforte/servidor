<?php
$string = "Variable String";
$float = 3.1416;
$integer = 4;
$bollean = true;
print "probando" . $string . " <br>";
echo "esto es un echo. $integer .<br>";
echo 'Y este con comillas simples ' . $float . '<br>';
define ("CONSTANTE", 100);
const COSNTANTE2 = 200;
echo CONSTANTE. "<br>";
echo COSNTANTE2 . "<br>";
echo PHP_INT_SIZE. "<br>";
echo PHP_INT_MIN . "<br>";