<?php
    define ('PATH', '/mvc_06');
