<?php
require("vendor/autoload.php");
require("./config/env.php");
$app = new \Core\App();
