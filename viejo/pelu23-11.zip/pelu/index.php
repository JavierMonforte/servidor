<?php
require("./core/App.php");
require("./config/env.php");
$app = new App();
