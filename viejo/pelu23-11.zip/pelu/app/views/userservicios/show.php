<!doctype html>
<html lang="es">

<head>
  <?php require "app/views/parts/head.php" ?>
</head>

<body>

  <?php require "app/views/parts/header.php" ?>

  <main role="main" class="container">
    <div class="starter-template">
      <h1>Detalle del usuario <?php echo $servicio->idservicio ?></h1>
        <ul>
            <li><strong>Servicio: </strong><?php echo $servicio->servicio ?></li>
            <li><strong>Descripcion: </strong><?php echo $servicio->descripcion ?></li>
            <li><strong>Tipo de Servicio: </strong><?php echo $servicio->tipoServicio ?></li>
            <li><strong>Precio: </strong><?php echo $servicio->precio?></li>
        </ul>
    </div>

  </main><!-- /.container -->
  <?php require "app/views/parts/footer.php" ?>


</body>
<?php require "app/views/parts/scripts.php" ?>

</html>