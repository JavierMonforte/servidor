<?php
namespace App\Controllers;

class PersonalController{


    function altaPersonal(){
        include("app/views/personal.php");
    } 
}