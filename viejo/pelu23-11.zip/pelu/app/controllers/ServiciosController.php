<?php
namespace App\Controllers;
require_once "app/models/Servicio.php";

use App\Models\Servicio;

class ServiciosController {


    function __construct()
    {
        // echo "En UserController";
    }

    public function index()
    {
        //buscar datos
        $servicios = Servicio::all();
        //pasar a la vista
        require("app/views/servicios.php");
    }
    
    public function create()
    {
        require 'app/views/user/create.php';
    }
    
    public function store()
    {
        $servicios = new Servicio();
        $servicios->servicio = $_REQUEST['name'];
        $servicios->descripcion = $_REQUEST['surname'];
        $servicios->tipoServicio = $_REQUEST['birthdate'];
        $servicios->precio = $_REQUEST['email'];
        $servicios->insert();
        header('Location:'.PATH.'servicios/');
    }
    
    public function show($args)
    {
        // $id = (int) $args[0];
        list($id) = $args;
        $servicios = Servicio::find($id);
        // var_dump($user);
        // exit();
        require('app/views/servicio/show.php');        
    }
    public function edit($arguments)
    {
        $id = (int) $arguments[0];
        $servicios = Servicio::find($id);
        require 'app/views/servicio/edit.php';
    }
    
    public function update()
    {
        $id = $_REQUEST['id'];
        $servicios = Servicio::find($id);
        $servicios->nombre = $_REQUEST['name'];
        $servicios->apellido = $_REQUEST['surname'];
        $servicios->fechaNacimiento = $_REQUEST['birthdate'];
        $servicios->email = $_REQUEST['email'];
        $servicios->save();
        header('Location:'.PATH.'servicios');
    }

    public function delete($arguments)
    {
        $id = (int) $arguments[0];
        $servicios = Servicio::find($id);
        $servicios->delete();
        header('Location:'.PATH.'servicios');
    }    
}