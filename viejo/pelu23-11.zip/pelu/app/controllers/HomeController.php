<?php
namespace App\Controllers;

/**
*
*/
class HomeController
{

    function __construct()
    {
        //echo "HomeController -> construct <br>";
    }

    public function index()
    {
        // echo "<p>En Index()</p>";
        require ("app/views/index.php");
    }

    public function menu(){
        require("app/views/menu.php");
    }
}