<?php 
namespace App\Controllers;

class CitasController{
    public function reservar()
    {
        require ("app/views/citas.php");
    }
}
