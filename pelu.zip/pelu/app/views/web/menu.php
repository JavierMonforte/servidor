<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Last-Modified" content="0">
    <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <link rel="stylesheet" href="/app/css/menu.css?i=<?=rand(1,100)?>">

</head>

<body>
<header>
    <div id="arribaIzquierda">
        <a id="mas" class="idioma" href="/citas/reservar">+</a>
        <a id="reservar" class="idioma" href="/citas/reservar">RESERVAR</a>
    </div>
    <div id="arribaDerecha">
        
        <a class="idioma" href="/home/index">X</a> 
    </div>
</header>
<div class="center">
<ul>
    <li><a href="/home/peluqueros">PELUQUEROS</a></li>
    <li><a href="/citas/reservar">CITAS</a></li>
    <li><a href="/home/servicios">SERVICIOS</a></li>
    <li><a href="">ABOUT</a></li>
    <li><a href="">TRABAJOS REALIZADOS</a></li>
    <li><a href="/users/index">APLICACION WEB</a></li>
    <li><a href="">SOMOS SOLIDARIOS</a></li>
</ul>
</div>
<footer>
    <div class="foot" id="abajoIdquierda">Avda Navarra</div>
    <div class="foot" id="abajoDerecha">669604539</div>
</footer>
   
</body>