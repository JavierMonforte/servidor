<header>
    <div id="arribaIzquierda">
        <a id="mas" href="/home/reservar">+</a>
        <a id="reservar"  href="/citas/reservar">RESERVAR</a>
    </div>
    <div id="arribaDerecha">
        
        <a class="idioma" href="/home/index">X</a> 
    </div>
</header>