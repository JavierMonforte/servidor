USE `pelu`;

DROP TABLE IF EXISTS `servicios`;
CREATE TABLE `servicios` (
  `idservicio` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `servicio` varchar(50) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `tipoServicio` int,
  `precio` double not null,
  INDEX (`idservicio`),
 FOREIGN KEY (tipoServicio) REFERENCES tipoServicios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `servicios` VALUES
(1, 'Pelo Corto','', 1, 0.8),
(2, 'Media Melena','', 1, 1),
(3, 'Pelo Largo','', 1, 1),
(4, 'Morena','', 2, 1),
(5, 'Rubia','', 2, 3),
(6, 'Pelirroja','', 2, 3)
;


