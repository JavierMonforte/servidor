<footer class="footer bottom bg-dark text-white">
    <div class="text-center" style="margin: 10px 0px 0px 0px; padding: 10px;">
        Pie de página
    </div>
</footer>
