<?php
    define ('PATH', '');
?>