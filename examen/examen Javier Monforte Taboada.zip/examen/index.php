<?php
require 'vendor/autoload.php';
require("./config/env.php");

//echo "Inicio<br>";
session_start();
$app = new \Core\App();
